export default { experimental:{ serverActions:{allowedOrigins:['*']} } }
