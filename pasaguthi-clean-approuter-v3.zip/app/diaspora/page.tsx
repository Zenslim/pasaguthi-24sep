export default function Page(){ return (<div className="space-y-4">
  <h1 className="text-3xl font-bold">Diaspora Stories</h1>
  <p className="opacity-80">Stories from Newars across the world.</p>
</div>); }
