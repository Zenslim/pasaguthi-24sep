export default function Page(){ return (<div className="space-y-4">
  <h1 className="text-3xl font-bold">Frequently Asked Questions</h1>
  <p className="opacity-80">Answers for the curious.</p>
</div>); }
