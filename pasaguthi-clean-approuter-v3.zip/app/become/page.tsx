export default function Page(){ return (<div className="space-y-4">
  <h1 className="text-3xl font-bold">Become a Member</h1>
  <p className="opacity-80">Sign in and complete your profile to become a Guthyar.</p>
</div>); }
