export default function Page(){ return (<div className="space-y-4">
  <h1 className="text-3xl font-bold">What is Pasaguthi?</h1>
  <p className="opacity-80">Pasaguthi is a DAO with a soul — an ancestral Guthi in digital form.</p>
</div>); }
