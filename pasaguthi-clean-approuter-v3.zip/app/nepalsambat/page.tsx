export default function Page(){ return (<div className="space-y-4">
  <h1 className="text-3xl font-bold">Nepal Sambat Calendar</h1>
  <p className="opacity-80">Living calendar module placeholder. (Hook later to your NS data API.)</p>
</div>); }
