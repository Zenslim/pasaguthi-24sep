# PasaGuthi — Clean App Router (V3, Menu + Whisper)
Routes included: `/` · `/signin` · `/dashboard` · `/profile/edit` · `/guthyars` · `/whisper` · `/nepalsambat` · `/about` · `/guthi` · `/vision` · `/how` · `/reflections` · `/diaspora` · `/faq` · `/become`
Run **sql/MasterReset.sql** in Supabase SQL Editor.
